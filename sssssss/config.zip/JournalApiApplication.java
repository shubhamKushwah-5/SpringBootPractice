package com.shubham.journal_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JournalApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(JournalApiApplication.class, args);
	}

}
